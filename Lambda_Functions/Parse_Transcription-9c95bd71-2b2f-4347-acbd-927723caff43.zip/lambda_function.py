import json
import boto3
import os
import urllib.request
import sys
import logging
import pymysql
from urllib.parse import urlparse
from datetime import datetime
import socket 
from contextlib import closing  # used for converting type AudioStream to a readable format
from tempfile import gettempdir # creates a temporary directory in the OS
import time  # adds delays in the code
import wave # to convert polly output to .wav

#BUCKET_NAME = "transcriptions.walkietalkie" #os.environ['BUCKET_NAME']

s3 = boto3.client('s3') #boto3.resource('s3')
transcribe = boto3.client('transcribe')
translate = boto3.client('translate')
polly = boto3.client('polly')

#rds settings
#https://docs.aws.amazon.com/lambda/latest/dg/services-rds-tutorial.html
rds_host  = "database-1.cml8g5orx21z.us-east-1.rds.amazonaws.com"
name = "admin"
password = "J3bpAdxfMbtN1vMlb48J"
db_name = "db1"


logger = logging.getLogger()
logger.setLevel(logging.INFO)

#connect to database
try:
    conn = pymysql.connect(host=rds_host, user=name, passwd=password, db=db_name, connect_timeout=5)
except pymysql.MySQLError as e:
    logger.error("ERROR: Unexpected error: Could not connect to MySQL instance.")
    logger.error(e)
    sys.exit()
        
logger.info("SUCCESS: Connection to RDS MySQL instance succeeded")
    
def lambda_handler(event, context):
        
    
    job_name = event['detail']['TranscriptionJobName']
    print(job_name)
    job = transcribe.get_transcription_job(TranscriptionJobName=job_name)
    #extract the job URI to access the raw transcription JSON and print it out to CloudWatch for reference
    uri = job['TranscriptionJob']['Transcript']['TranscriptFileUri']
    audio_uri = job['TranscriptionJob']['Media']['MediaFileUri']
    
    o = urlparse(audio_uri)
    bucket, key = os.path.split(o.path)
    print(bucket.lstrip('/'), key)
    
    #get metadata
    metadata = s3.head_object(Bucket=bucket.lstrip('/'), Key=key)
    source_lang_id = metadata['Metadata']['source_lang']
    target_lang_id = metadata['Metadata']['target_lang']
    user_id = metadata['Metadata']['user_id']
    room = metadata['Metadata']['room']
    
    out_bucket = "synthesized.walkietalkie" #store synthesized audio file here
    
    #get language code for translation
    try:
        with conn.cursor() as cur:
            cur.execute("select translate_lang_code from languages where id = '%s'" % (source_lang_id))
            source_lang=cur.fetchall()[0][0]

            cur.execute("select translate_lang_code from languages where id = '%s'" % (target_lang_id))
            target_lang=cur.fetchall()[0][0]
            
            cur.execute("select polly_lang_code from languages where id = '%s'" % (target_lang_id))
            polly_lang=cur.fetchall()[0][0]

            
        if len(source_lang)==0:
            print('There is no language code with id ', source_lang_id)
        if len(target_lang)==0:
            print('There is no language code with id ', target_lang_id)
    except Exception as e:
        raise Exception("[ErrorMessage]: " + str(e))
    
    
    #make an HTTP request to grab the content of the transcription from the URI
    content = urllib.request.urlopen(uri).read().decode('UTF-8')
    #write content to cloudwatch logs
    print(json.dumps(content))
    
    data =  json.loads(content)
    transcribed_text = data['results']['transcripts'][0]['transcript']
    
    #create an s3 object which is a text file, and write the contents of the transcription to it
    #object = s3.Object(BUCKET_NAME,job_name+"_Output.txt")
    #object.put(Body=transcribed_text)
    
    '''try:
        # The Lambda function queries the Amazon RDS table to check whether 
        # the text has already been translated. If the translated text
        # is already stored in Amazon RDS, the function returns it.
        with conn.cursor() as cur:
            cur.execute("select msg_target FROM messages where msg_original = '%s' and original_language = '%s' and target_language = '%s'" % (transcribed_text, source_lang, target_lang))
            data=cur.fetchall()
            print(data)
            
        if len(data)==0:
            print('There is no translation for ', transcribed_text)
        else:
            print('Translation exists for: %s -> %s' %(transcribed_text,data[0]))
            #delete transcription job
            initialize_socket()
            transcribe.delete_transcription_job(TranscriptionJobName=job_name)
            return 
            
    except Exception as e:
        #logger.error(response)
        raise Exception("[ErrorMessage]: " + str(e))'''
    
    
    #translate
    try:
        # The Lambda function calls the TranslateText operation and passes the 
        # review, the source language, and the target language to get the 
        # translated review. 
        result = translate.translate_text(Text=transcribed_text, SourceLanguageCode=source_lang, TargetLanguageCode=target_lang)
        logging.info("Translation output: " + str(result))
    except Exception as e:
        logger.error('Translation failed')
        raise Exception("[ErrorMessage]: " + str(e))
        
    translation = result.get('TranslatedText')
    print("translation: " + translation)
    
    #DB PUT
    # with conn.cursor() as cur:
    #     insert_tuple = (0, user_id, source_lang_id, target_lang_id, transcribed_text, translation, room)
    #     cur.execute('insert into messages (id, userID, original_language, target_language, msg_original, msg_target, room) values(%s, %s, %s, %s, %s, %s, %s)', insert_tuple)
    # conn.commit()
    
    voices = {
      'de-DE': 'Vicki',
      'en-US': 'Joanna',
      'cmn-CN': 'Zhiyu'
    }

    voice = voices[polly_lang]
    
    #speech synthesis (polly)
    # try:
    #     polly_response = polly.synthesize_speech(
    #         LanguageCode = polly_lang,
    #         OutputFormat='mp3',
    #         Text = translation, #translate_response['TranslatedText'],
    #         VoiceId = voice
    #     )
    # except Exception as e:
    #     logger.error('Polly failed')
    #     raise Exception("[ErrorMessage]: " + str(e))
    
    # if "AudioStream" in polly_response:
    #     with closing(polly_response["AudioStream"]) as stream:
    #         output = os.path.join(gettempdir(), job_name + ".mp3")
    #         try:
    #             with open(output, "wb") as file:
    #                 file.write(stream.read())
    #         except IOError as error: 
    #             time.sleep(0.1)
                
    try:
      polly_response = polly.synthesize_speech(
              LanguageCode = polly_lang,
              OutputFormat='pcm',
              Text=translation,
              VoiceId=voice
            )
    
      if 'AudioStream' in polly_response:
        wave_file_path = '/tmp/my-audio.wav'
        with wave.open(wave_file_path, 'wb') as wav_file:
          wav_file.setparams((1, 2, 16000, 0, 'NONE', 'NONE'))
          wav_file.writeframes(polly_response['AudioStream'].read())
        
        # if you need wav in binary
        # wav_data = None
        # with wave.open(wave_file_path, 'rb') as wav_file:
        #   # get wav binary using read() method
        #   wav_data = wav_file.read()
      
        # if os.path.exists(wave_file_path):
        #   os.unlink(wave_file_path)
        
        # return wav_data
    except Exception as e:
      print('synthesize_speech exception: ', e)
                
    
                
                
    #get language code for translation
    # try:
    #     with conn.cursor() as cur: 
    #         cur.execute("SELECT id FROM messages ORDER BY id DESC LIMIT 1")
    #         msg_id=cur.fetchall()[0][0]
    #         msg_id = str(msg_id)
    #         print(msg_id)
            
    #     if len(msg_id)==0:
    #         print('Row did not get inserted')
    
    # except Exception as e:
    #     raise Exception("[ErrorMessage]: " + str(e))

    
    #response = s3.upload_file(output, out_bucket, job_name+".mp3", ExtraArgs={'ACL':'public-read'})
    response = s3.upload_file(wave_file_path, out_bucket, job_name+".wav", ExtraArgs={'ACL':'public-read'})

    object_url = 'https://s3.amazonaws.com/{0}/{1}'.format(out_bucket, job_name+".wav")
    print(object_url)

        
    #DB PUT
    with conn.cursor() as cur:
        #update_tuple = (object_url, datetime.now(), msg_id)
        #cur.execute('update messages set msg_speech = "%s", created_at = "%s" where id = "%s"', update_tuple)
        insert_tuple = (0, user_id, datetime.now(), source_lang_id, target_lang_id, transcribed_text, translation, object_url, room)
        cur.execute('insert into messages (id, userID, created_at, original_language, target_language, msg_original, msg_target, msg_speech, room) values(%s, %s, %s, %s, %s, %s, %s, %s, %s)', insert_tuple)
    conn.commit()
    
    # send db updated msg
    send_db_updated()
    
    #delete transcription job
    transcribe.delete_transcription_job(TranscriptionJobName=job_name)
    
    
def send_db_updated():
    client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)  # initialazing socket with TCP and IPv4
    remote_ip = 'ec2-34-195-127-232.compute-1.amazonaws.com'
    remote_port = 10319  # TCP port
    try:
        client_socket.connect((remote_ip, remote_port))  # connect to the remote server
        socket_connected = True
    except:
        socket_connected = False
        print('socket connect failed')
    else:
        print('socket connect success')
        
    message = ("!DB_UPDATED").encode('utf-8')
    if socket_connected:
        try:
            client_socket.send(message)
            client_socket.close()
        except:
            print('could not connect to server; check if server is online') 
    else:
        print('socket not connected; message not sent')
    
