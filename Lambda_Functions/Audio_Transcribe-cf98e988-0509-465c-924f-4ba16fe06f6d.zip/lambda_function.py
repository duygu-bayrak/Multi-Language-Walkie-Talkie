import boto3
import time
import logging
import pymysql

#Create low level clients for s3 and Transcribe
s3  = boto3.client('s3')
transcribe = boto3.client('transcribe')

logger = logging.getLogger()
logger.setLevel(logging.INFO)

#rds settings
rds_host  = "database-1.cml8g5orx21z.us-east-1.rds.amazonaws.com"
name = "admin"
password = "J3bpAdxfMbtN1vMlb48J"
db_name = "db1"

#connect to database
try:
    conn = pymysql.connect(host=rds_host, user=name, passwd=password, db=db_name, connect_timeout=5)
except pymysql.MySQLError as e:
    logger.error("ERROR: Unexpected error: Could not connect to MySQL instance.")
    logger.error(e)
    sys.exit()
        
logger.info("SUCCESS: Connection to RDS MySQL instance succeeded")

def lambda_handler(event, context):
    
    #parse out the bucket & file name from the event handler
    for record in event['Records']:
        file_bucket = record['s3']['bucket']['name']
        file_name = record['s3']['object']['key']
        object_url = 'https://s3.amazonaws.com/{0}/{1}'.format(file_bucket, file_name)
        
        #get metadata
        metadata = s3.head_object(Bucket=file_bucket, Key=file_name)
        source_lang = metadata['Metadata']['source_lang']
        #target_lang = metadata['Metadata']['target_lang']
        #user_id = metadata['Metadata']['user_id']
        
        #get language code
        try:
            with conn.cursor() as cur:
                cur.execute("select transcribe_lang_code from languages where id = '%s'" % (source_lang))
                lang_code=cur.fetchall()[0][0]
                print(lang_code)
                
            if len(lang_code)==0:
                print('There is no language code with id ', source_lang)
        except Exception as e:
            raise Exception("[ErrorMessage]: " + str(e))
        
        
                
        #print(time.time())
        
        #translate
        try:
            # The Lambda function calls the TranscribeText operation
            response = transcribe.start_transcription_job(
                TranscriptionJobName=file_name.replace('/','')[:10],
                LanguageCode=lang_code,
                MediaFormat='wav',
                Media={
                    'MediaFileUri': object_url
                })
        except Exception as e:
            raise Exception("[ErrorMessage]: " + str(e))
        
        print(response)
        
        #update d