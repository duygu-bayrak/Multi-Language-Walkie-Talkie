# https://docs.aws.amazon.com/translate/latest/dg/examples-ddb.html
# https://docs.aws.amazon.com/translate/latest/dg/examples-ddb.html#examples-ddb-code-lambda

#NOT USED: Merged with Parse_Transcription

import logging
import json
import boto3
import os
import sys
import pymysql

translate = boto3.client('translate')
#s3  = boto3.client('s3')
s3 = boto3.resource('s3')


#rds settings
rds_host  = "database-1.cml8g5orx21z.us-east-1.rds.amazonaws.com"
name = "admin"
password = "J3bpAdxfMbtN1vMlb48J"
db_name = "db1"

#TABLE_NAME = os.getenv('TABLE_NAME')

logger = logging.getLogger()
logger.setLevel(logging.INFO)

BUCKET_NAME = "translations.walkietalkie"

try:
    conn = pymysql.connect(host=rds_host, user=name, passwd=password, db=db_name, connect_timeout=5)
except pymysql.MySQLError as e:
    logger.error("ERROR: Unexpected error: Could not connect to MySQL instance.")
    logger.error(e)
    sys.exit()
    

def lambda_handler(event, context):

    logger.info(event)

    #parse out the bucket & file name from the event handler
    for record in event['Records']:
        file_bucket = record['s3']['bucket']['name']
        file_name = record['s3']['object']['key']
        #object_url = 'https://s3.amazonaws.com/{0}/{1}'.format(file_bucket, file_name) #if source_language' in event and 'target_language' in event and 'review' in event and 'review_id' in event:
        
        #review_id = event['review_id']
        source_language = "en" #event['source_language']
        target_language = "de" #event['target_language']
        #text = event['text'] #text to translate

        try:
            obj = s3.Object(file_bucket, file_name)
        except Exception as e:
            print(f"Error reading key {file_name} from bucket {file_bucket}: {e}")
        else:
           print(f"Got object: {obj}")
           text = obj.get()['Body'].read().decode('utf-8') 
           print('text: '+ text) 
           


        try:
            # The Lambda function calls the TranslateText operation and passes the 
            # review, the source language, and the target language to get the 
            # translated review. 
            result = translate.translate_text(Text=text, SourceLanguageCode=source_language, TargetLanguageCode=target_language)
            logging.info("Translation output: " + str(result))
        except Exception as e:
            logger.error(result)
            raise Exception("[ErrorMessage]: " + str(e))
        
        
        translation = result.get('TranslatedText')
        print("translation: " + translation)
        
        #create an s3 object which is a text file, and write the contents of the transcription to it
        #object = s3.Object(BUCKET_NAME , file_name+"_translated.txt")
        #object.put(Body=translation)

 
