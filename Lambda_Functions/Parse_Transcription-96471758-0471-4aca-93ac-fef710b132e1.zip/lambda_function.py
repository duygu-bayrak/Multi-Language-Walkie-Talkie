import json
import boto3
import os
import urllib.request
import sys
import logging
import pymysql

BUCKET_NAME = "transcriptions.walkietalkie" #os.environ['BUCKET_NAME']

s3 = boto3.resource('s3')
transcribe = boto3.client('transcribe')
translate = boto3.client('translate')

#rds settings
#https://docs.aws.amazon.com/lambda/latest/dg/services-rds-tutorial.html
rds_host  = "database-1.cml8g5orx21z.us-east-1.rds.amazonaws.com"
name = "admin"
password = "J3bpAdxfMbtN1vMlb48J"
db_name = "db1"

source_language = "en" 
target_language = "de"

logger = logging.getLogger()
logger.setLevel(logging.INFO)

try:
    conn = pymysql.connect(host=rds_host, user=name, passwd=password, db=db_name, connect_timeout=5)
except pymysql.MySQLError as e:
    logger.error("ERROR: Unexpected error: Could not connect to MySQL instance.")
    logger.error(e)
    sys.exit()
        
logger.info("SUCCESS: Connection to RDS MySQL instance succeeded")
    
def lambda_handler(event, context):
    
    job_name = event['detail']['TranscriptionJobName']
    job = transcribe.get_transcription_job(TranscriptionJobName=job_name)
    #extract the job URI to access the raw transcription JSON and print it out to CloudWatch for reference
    uri = job['TranscriptionJob']['Transcript']['TranscriptFileUri']
    print(uri)
    
    #make an HTTP request to grab the content of the transcription from the URI
    content = urllib.request.urlopen(uri).read().decode('UTF-8')
    #write content to cloudwatch logs
    print(json.dumps(content))
    
    data =  json.loads(content)
    transcribed_text = data['results']['transcripts'][0]['transcript']
    
    #create an s3 object which is a text file, and write the contents of the transcription to it
    #object = s3.Object(BUCKET_NAME,job_name+"_Output.txt")
    #object.put(Body=transcribed_text)
    
    
    #translate
    try:
        # The Lambda function calls the TranslateText operation and passes the 
        # review, the source language, and the target language to get the 
        # translated review. 
        result = translate.translate_text(Text=transcribed_text, SourceLanguageCode=source_language, TargetLanguageCode=target_language)
        logging.info("Translation output: " + str(result))
    except Exception as e:
        logger.error('Translation failed')
        raise Exception("[ErrorMessage]: " + str(e))
        
        
    translation = result.get('TranslatedText')
    print("translation: " + translation)
        
    #DB PUT
    with conn.cursor() as cur:
        print('insert into translations (translations_id, text_en, text_de) values(0, %s, %s)' % (transcribed_text, translation))
        insert_tuple = (0, transcribed_text, translation)
        cur.execute('insert into translations (translations_id, text_en, text_de) values(%s, %s, %s)', insert_tuple)
    conn.commit()
    
    #delete transcription job
    transcribe.delete_transcription_job(TranscriptionJobName=job_name)
    
